const express = require('express');
const router = express.Router();

//introducing the controller
const controller = require('../controllers/controller');

//all requests(GET & POST)
router.all('/feed', controller.getFeed);
router.get('/showMessage/:id', controller.getSMessage);
router.get('/delete/:id', controller.dMessage);
router.get('/editMessage/:id', controller.gMessage);

router.post('/editMessage/:id', controller.eMessage);

// export the router
module.exports = router;