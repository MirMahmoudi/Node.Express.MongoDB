// to get mongoose 
const mongoose = require('mongoose');

// to identify where is the database: here database is local
const localDB = 'mongodb://localhost/examChallenge';

//connect to the local database
mongoose.connect(localDB, { useNewUrlParser: true , useUnifiedTopology: true })
    .then( () => console.log('connected toDB'))
    .catch(err => console.log(err))