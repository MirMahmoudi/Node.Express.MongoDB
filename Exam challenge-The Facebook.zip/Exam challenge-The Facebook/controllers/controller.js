//model file
const { FEED }  = require('../models/feed');


// rendering the homepage with name:feed
const getFeed = (req, res) => {
    // GET request function
    if(req.method === 'GET'){
        FEED.find()
            .then(response => {
                res.render('feed', {response, pageTitle: 'Feed', error: false })
            })
            .catch(err => {
                console.log(err.errors);
            })
    };
    
        // POST request function
    if(req.method === 'POST'){
        // console.log(req.body, 'This mes. comes from POST of feed-page');
        const feed = new FEED(req.body);
        // console.log(feed, req.body, 'This mes. comes from POST of feed-page');
        feed.save()
            .then(response => {
                // console.log(response, 'response of feed-page from then');
                res.redirect('/feed');
            })
            .catch(err => {
                // console.log(err.errors.name.properties.message, 'message from error');
                FEED.find()
                .then(response => {
                    res.render('feed', {response, pageTitle: 'Feed', error: err.errors })
                })
                .catch(err => {
                    console.log(err.errors);
                })
            })
    };
};


// showing the facebook post that was selected in another page
const getSMessage = (req, res) => {
    FEED.findById(req.params.id)
        .then(response => {
            res.render('showMessage', {response, pageTitle: 'Message' })
        })
        .catch(err => {
            console.log(err.errors);
        })
};


// by this function, delete the selected post
const dMessage = (req, res) => {
    FEED.findByIdAndDelete(req.params.id)
    // console.log(req.params.id, 'here is dMessage');
        .then(response => {
            res.redirect('/feed')
        })
        .catch(err => {
            console.log(err.errors);
        })
};


// by this function, the data of selected Post can be put it in the form and ready to edit
const gMessage = (req, res) => {
    FEED.findById({_id: req.params.id})
        .then(response => {
            res.render('editMessage', {response, pageTitle: 'Edit Message', error: false } )
        })
        .catch(err => {
            console.log(err.errors);
        })
};


// by this function, it is possible to edit the selected post
const eMessage = (req, res) => {
    FEED.findByIdAndUpdate({_id: req.params.id})
        .then(response => {
            response.name = req.body.name;
            response.message = req.body.message;
            response.save()
                .then( () => {
                    // console.log(response, 'Here is eMessage in THEN');
                    res.render('showMessage', {response, pageTitle: 'Message' })
                })
                .catch(err => {
                    // console.log(err.errors)
                    res.render('editMessage', {response , pageTitle:'Edit Message', error:err.errors})
                })
        })
        .catch(err => {
            console.log(err.errors);
        })
};

module.exports = {
    getFeed,
    getSMessage,
    dMessage,
    gMessage,
    eMessage
};